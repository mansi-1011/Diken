// next.config.mjs
const nextConfig = {
  distDir: '_next',
  experimental: {
    appDir: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
